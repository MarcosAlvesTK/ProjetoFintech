package controller;

import conf.DataBaseConnector;
import model.PessoaFisica;
import model.Saldo;
import repository.SaldoRepository;
import repository.impl.SaldoRepositoryImpl;

import java.sql.SQLException;
import java.util.Scanner;

public class MenuController {

    PessoaController pessoaController = new PessoaController();

    public void menu(PessoaFisica index) throws SQLException {
        SaldoController saldoController = new SaldoController();
        Scanner sc1 = new Scanner(System.in);
        Scanner sSaque = new Scanner(System.in);
        Scanner sDeposito = new Scanner(System.in);
        Integer selecionaMenu=9;
        while(selecionaMenu!=0){
            System.out.println("1 - Depositar ");
            System.out.println("2 - Sacar ");
            System.out.println("3 - Extrato ");
            System.out.println("0 - Sair ");
            System.out.println("Selecione o menu: ");
            selecionaMenu=sc1.nextInt();

            switch(selecionaMenu){
                case 1:
                    System.out.println("Digite o valor de deposito ");
                    saldoController.depositarSaldo(sDeposito.nextInt(),index.getSaldo());
                break;
                case 2:
                    System.out.println("Digite o valor de Saque ");
                    saldoController.sacarSaldo(sSaque.nextInt(),index.getSaldo());
                break;
                case 3:
                    System.out.println("Seu saldo é R$ "+ saldoController.extratoSaldo(index.getSaldo()).getSaldoCredito());
                break;
                case 0:
                    System.out.println("saindo");
                break;
            }
        }
    }

    public void menuConta() throws SQLException {
        SaldoRepository saldoRepository = new SaldoRepositoryImpl();
        Scanner sc1 = new Scanner(System.in);
        Scanner sCpf = new Scanner(System.in);
        Scanner sNome = new Scanner(System.in);
        Scanner sNascimento = new Scanner(System.in);
        Scanner sEmail = new Scanner(System.in);
        Scanner sTelefone = new Scanner(System.in);
        Scanner sConsultaConta = new Scanner(System.in);
        Integer selecionaMenu = 9;
        while (selecionaMenu != 0) {
            System.out.println("1 - Criar Conta ");
            System.out.println("2 - Consultar Conta ");
            System.out.println("0 - Sair ");
            System.out.println("Selecione o menu: ");
            selecionaMenu = sc1.nextInt();

            switch (selecionaMenu) {
                case 1:
                    PessoaFisica pessoa = new PessoaFisica();
                    System.out.println("Digite o CPF da pessoa ");
                    pessoa.setCpf(sCpf.nextLine());
                    System.out.println("Digite o Nome da pessoa ");
                    pessoa.setNome(sNome.nextLine());
                    System.out.println("Digite o Nascimento da pessoa ");
                    pessoa.setNascimento(sNascimento.nextLine());
                    System.out.println("Digite o Email da pessoa ");
                    pessoa.setEmail(sEmail.nextLine());
                    Saldo inputSaldo = new Saldo(0,0,saldoRepository.idSaldo());
                    saldoRepository.incluirSaldo(inputSaldo);
                    pessoa.setSaldo(inputSaldo.getId());
                    System.out.println("Digite o Telefone da pessoa ");
                    pessoa.setTelefone(sTelefone.nextLine());
                    pessoaController.criarPessoaFisica(pessoa);
                    System.out.println("Conta aberta!");
                    break;
                case 2:
                    System.out.println("Digite o cpf da conta que deseja consultar ");
                    PessoaFisica index = pessoaController.getPessoaFisica(sConsultaConta.nextLine());
                    if(index==null) {
                        System.out.println("Cpf incorreto");
                        break;
                    }
                    menu(index);
                    break;
            }
        }
        DataBaseConnector.dataBaseConnector();
    }
}
