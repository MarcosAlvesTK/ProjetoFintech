package controller;

import model.Saldo;
import repository.SaldoRepository;
import repository.impl.SaldoRepositoryImpl;

import java.sql.SQLException;

public class SaldoController {
    private SaldoRepository saldoRepository = new SaldoRepositoryImpl();

    public void depositarSaldo(Integer deposito, Integer index) throws SQLException {
        Saldo saldo = new Saldo();
        saldo = saldoRepository.findBySaldo(index);
        Integer valor = deposito+saldo.getSaldoCredito();
        saldoRepository.depositoSaldo(valor,index);

    }

    public void sacarSaldo(Integer saque, Integer index) throws SQLException {
        Saldo saldo = new Saldo();
        saldo = saldoRepository.findBySaldo(index);
        Integer depRegs = saldo.getSaldoCredito() - saque;
        Integer saqRegs = saldo.getSaldoDebito()+saque;
        saldoRepository.depositoSaldo(depRegs,index);
        saldoRepository.saqueSaldo(saqRegs,index);
    }

    public Saldo extratoSaldo(Integer index) throws SQLException {
        return saldoRepository.findBySaldo(index);
    }
}
