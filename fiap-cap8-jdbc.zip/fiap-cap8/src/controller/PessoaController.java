package controller;

import model.Pessoa;
import model.PessoaFisica;
import model.Saldo;
import repository.ContaRepository;
import repository.impl.ContaRepositoryImpl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PessoaController {

    ContaRepository contaRepository = new ContaRepositoryImpl();

    public void criarPessoaFisica(PessoaFisica pessoa) throws SQLException {
        contaRepository.insertConta(pessoa);
    }

    public PessoaFisica getPessoaFisica(String cpf) throws SQLException {
        return contaRepository.pessoaFisica(cpf);
    }
}
