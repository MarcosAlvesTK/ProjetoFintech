import controller.MenuController;

import java.sql.SQLException;

public class Main {
    public static void main(String[] args) throws SQLException {
        System.out.println("Hello world!");
        MenuController menuController = new MenuController();
        menuController.menuConta();
    }
}