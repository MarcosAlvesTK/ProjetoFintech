package repository;

import model.Saldo;

import java.sql.SQLException;

public interface SaldoRepository {
    public void incluirSaldo(Saldo saldo) throws SQLException;
    public Saldo findBySaldo(Integer id) throws SQLException;
    public Integer idSaldo() throws SQLException;

    public void depositoSaldo(Integer deposito, Integer id) throws SQLException;

    void saqueSaldo(Integer saque, Integer saldo) throws SQLException;
}
