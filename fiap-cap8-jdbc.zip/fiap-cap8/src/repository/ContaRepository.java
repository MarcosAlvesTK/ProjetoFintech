package repository;

import model.PessoaFisica;

import java.sql.SQLException;
import java.util.List;

public interface ContaRepository {
    public List<PessoaFisica> findAllConta() throws SQLException;
    public void insertConta(PessoaFisica pessoaFisica) throws SQLException;
    public PessoaFisica pessoaFisica(String cpf) throws SQLException;
}
