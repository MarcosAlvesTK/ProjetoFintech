package repository.impl;

import conf.DataBaseConnector;
import model.PessoaFisica;
import model.Saldo;
import repository.ContaRepository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ContaRepositoryImpl implements ContaRepository {

    @Override
    public List<PessoaFisica> findAllConta() throws SQLException {
        Connection connection = DataBaseConnector.dataBaseConnector();
        List<PessoaFisica> result = new ArrayList<PessoaFisica>();
        PreparedStatement ps = connection.prepareStatement("SELECT * FROM TB_PESSOA");
        ResultSet resultSet = ps.executeQuery();
        while(resultSet.next()){
            PessoaFisica pessoaFisica = new PessoaFisica(
                    resultSet.getString("DS_EMAIL"),
                    resultSet.getString("NR_TELEFONE"),
                    resultSet.getInt("CD_SALDO"),
                    resultSet.getString("NR_CPF"),
                    resultSet.getString("DT_NASCIMENTO"),
                    resultSet.getString("NM_NOME")
                    );
            result.add(pessoaFisica);
        }
        connection.close();
        return result;
    }

    @Override
    public void insertConta(PessoaFisica pessoaFisica) throws SQLException {
        Connection connection = DataBaseConnector.dataBaseConnector();
        PreparedStatement ps = connection.prepareStatement("INSERT INTO TB_PESSOA VALUES (?,?,?,?,?,?)");
        ps.setString(1, pessoaFisica.getEmail());
        ps.setString(2, pessoaFisica.getTelefone());
        ps.setInt(3,pessoaFisica.getSaldo());
        ps.setString(4, pessoaFisica.getCpf());
        ps.setString(5, pessoaFisica.getNome());
        ps.setString(6,pessoaFisica.getNascimento());
        ps.executeUpdate();
        connection.close();
    }

    @Override
    public PessoaFisica pessoaFisica(String cpf) throws SQLException {
        Connection connection = DataBaseConnector.dataBaseConnector();
        PessoaFisica result = new PessoaFisica();
        PreparedStatement ps = connection.prepareStatement("SELECT * FROM TB_PESSOA where nr_cpf = ?");
        ps.setString(1,cpf);
        ResultSet resultSet = ps.executeQuery();
        if(resultSet.next()){
            PessoaFisica pessoaFisica = new PessoaFisica(
                    resultSet.getString("DS_EMAIL"),
                    resultSet.getString("NR_TELEFONE"),
                    resultSet.getInt("CD_SALDO"),
                    resultSet.getString("NR_CPF"),
                    resultSet.getString("DT_NASCIMENTO"),
                    resultSet.getString("NM_NOME")
            );
            return pessoaFisica;
        }
        connection.close();
        return result;
    }
}
