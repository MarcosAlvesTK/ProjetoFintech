package repository.impl;

import conf.DataBaseConnector;
import model.Saldo;
import repository.SaldoRepository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SaldoRepositoryImpl implements SaldoRepository {
    @Override
    public void incluirSaldo(Saldo saldo) throws SQLException {
        Connection connection = DataBaseConnector.dataBaseConnector();
        PreparedStatement ps = connection.prepareStatement("INSERT INTO TB_SALDO VALUES (?,?,?)");
        ps.setInt(1, saldo.getSaldoDebito());
        ps.setInt(2, saldo.getSaldoCredito());
        ps.setInt(3, saldo.getId());
        ps.executeUpdate();

        connection.close();
    }

    @Override
    public Saldo findBySaldo(Integer id) throws SQLException {
        Connection connection = DataBaseConnector.dataBaseConnector();
        Saldo result = new Saldo();
        PreparedStatement ps = connection.prepareStatement("SELECT * FROM TB_SALDO WHERE CD_SALDO = ?");
        ps.setInt(1,id);
        ResultSet resultSet = ps.executeQuery();
        if(resultSet.next()){
            result.setSaldoDebito(resultSet.getInt("NR_SALD_DEBITO"));
            result.setSaldoCredito(resultSet.getInt("NR_SALD_CREDITO"));
            result.setId(resultSet.getInt("CD_SALDO"));
        }
        return result;
    }

    @Override
    public Integer idSaldo() throws SQLException {
        Connection connection = DataBaseConnector.dataBaseConnector();
        Integer result = 0;
        PreparedStatement ps = connection.prepareStatement("select sequence_saldo.nextval as cd_saldo from dual");
        ResultSet resultSet = ps.executeQuery();
        if(resultSet.next())
            result = resultSet.getInt("cd_saldo");
        return result;
    }

    @Override
    public void depositoSaldo(Integer deposito, Integer id) throws SQLException {
        Connection connection = DataBaseConnector.dataBaseConnector();
        PreparedStatement ps = connection.prepareStatement("update tb_saldo set nr_sald_credito = ? where cd_saldo=?");
        ps.setInt(1,deposito);
        ps.setInt(2,id);
        ps.executeUpdate();
        connection.commit();
        connection.close();
    }

    @Override
    public void saqueSaldo(Integer saque, Integer saldo) throws SQLException {
        Connection connection = DataBaseConnector.dataBaseConnector();
        PreparedStatement ps = connection.prepareStatement("update tb_saldo set nr_sald_debito = ? where cd_saldo=?");
        ps.setInt(1,saque);
        ps.setInt(2,saldo);
        ps.executeUpdate();
        connection.commit();
        connection.close();
    }


}
