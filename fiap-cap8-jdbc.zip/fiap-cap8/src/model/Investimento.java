package model;

public class Investimento {
    Integer valorInvestido;

    public Integer getValorInvestido() {
        return valorInvestido;
    }

    public void setValorInvestido(Integer valorInvestido) {
        this.valorInvestido = valorInvestido;
    }

    public Investimento(){}

    public Investimento(Integer valorInvestido) {
        this.valorInvestido = valorInvestido;
    }
}
