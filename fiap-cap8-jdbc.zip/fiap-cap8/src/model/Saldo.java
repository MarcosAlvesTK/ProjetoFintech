package model;

public class Saldo {
    private Integer saldoDebito;
    private Integer saldoCredito;

    private Integer id;

    public Saldo(){}
    public Saldo(Integer saldoDebito, Integer saldoCredito, Integer id) {
        this.saldoDebito = saldoDebito;
        this.saldoCredito = saldoCredito;
        this.id = id;
    }

    public Integer getSaldoDebito() {
        return saldoDebito;
    }

    public void setSaldoDebito(Integer saldoDebito) {
        this.saldoDebito = saldoDebito;
    }

    public Integer getSaldoCredito() {
        return saldoCredito;
    }

    public void setSaldoCredito(Integer saldoCredito) {
        this.saldoCredito = saldoCredito;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}
