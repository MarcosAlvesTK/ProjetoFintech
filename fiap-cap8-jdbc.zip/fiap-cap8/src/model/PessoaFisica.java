package model;

import java.util.Date;

public class PessoaFisica extends Pessoa{
    private String cpf;
    private String nascimento;
    private String nome;

    public PessoaFisica(){}

    public PessoaFisica(String email, String telefone, Integer saldo, String cpf, String nascimento, String nome) {
        super(email, telefone, saldo);
        this.cpf = cpf;
        this.nascimento = nascimento;
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getNascimento() {
        return nascimento;
    }

    public void setNascimento(String nascimento) {
        this.nascimento = nascimento;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}
