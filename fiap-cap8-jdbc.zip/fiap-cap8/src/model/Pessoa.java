package model;

public class Pessoa {
    private String email;
    private String telefone;

    private Integer saldo;

    public Pessoa(){

    }

    public Pessoa(String email, String telefone, Integer saldo) {
        this.email = email;
        this.telefone = telefone;
        this.saldo = saldo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public Integer getSaldo() {
        return saldo;
    }

    public void setSaldo(Integer saldo) {
        this.saldo = saldo;
    }
}
