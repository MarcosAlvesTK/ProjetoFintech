package conf;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DataBaseConnector {

    public static Connection dataBaseConnector() {
        try {
            //Registra o Driver
            Class.forName("oracle.jdbc.driver.OracleDriver");
            //Abre uma conexão


            System.out.println("Conectado!");

            //Fecha a conexão
            return  DriverManager.getConnection(
                    "jdbc:oracle:thin:@localhost:1521/XEPDB1", "system", "dudu9202");
            //Tratamento de erro
        } catch (SQLException e) {
            System.err.println("Não foi possível conectar no Banco de Dados");
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            System.err.println("O Driver JDBC não foi encontrado!");
            e.printStackTrace();
        }
        return null;
    }
}
